Example bigquery usage:

python reporter.py --project_id your_project_id --dataset_name your_dataset_name --table_name your_table_name --format html

Example Postgres usage:

python reporter_pg.py --db_type postgres --postgres_host your_postgres_host --postgres_port your_postgres_port --postgres_user your_postgres_user --postgres_password your_postgres_password --postgres_database your_postgres_database 
